package info.johnmurphyastro.stuff;

/**
 * Demonstrates an enum class
 * @author John Murphy
 */
public enum PlanetEnum {
    MERCURY,
    VENUS,
    EARTH,
    MARS,
    JUPITER,
    SATURN,
    URANUS,
    NEPTUNE
}
